-- show a report that contains the  firstname, lastname, account number and email;


 

-- show the same report, but avoid this time the presence of the elements with empty 
-- value for the account number


 

--- using the card detail and the account details tables,
-- prepare a report where you show for each account that is a checking account
-- the several cards linked to that  account , columns shown are: AccountNumber,  CardNumber, AccountType  
 


--- look at the precedent report. You realise there is a multiple relation (at least)
-- now you want to be sure of wich account has a more than one card related to it
--- name the statistic variable number_of_cards and group by AccountNumber

 


-- you have shown the precedent report to the client, 
-- there is no particular issues with these data.
-- On the other hand, now we want to know if there are cards related to 
-- saving accounts. In the next lesson we are going to 
--make an intervention on those one


 

--- to prepare a campaig, the marketing department want to know name, lastname, mail of the clients
-- that has cards from Magistercart and Lisa circuit: 
-- (tips you will need now to join 4 tables!!!). 
-- further more, you have to trasnform data from cardinfo table to join it the appropriat table
-- the function tha does it



SELECT CAST(SUBSTR(CardNumber, 3) AS INTEGER) AS CardNumberNumeric
FROM CardInfo;

 



-- modify the precedent report because the marketind department does not want the client living in 'New Berlin'
-- to be eligible

 